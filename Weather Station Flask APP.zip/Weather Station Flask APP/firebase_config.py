
firebaseConfig = {
  "apiKey": "AIzaSyDVJFcGq6sbnHNycjBsBM0XB02v4ycLCJE",
  "authDomain": "weatherstation-32e7d.firebaseapp.com",
  "databaseURL": "https://weatherstation-32e7d-default-rtdb.firebaseio.com",
  "projectId": "weatherstation-32e7d",
  "storageBucket": "weatherstation-32e7d.appspot.com",
  "messagingSenderId": "471763717730",
  "appId": "1:471763717730:web:6c79d3b0b4aaf96993cb3b",
  "measurementId": "G-3L6VSHBXH8"
}